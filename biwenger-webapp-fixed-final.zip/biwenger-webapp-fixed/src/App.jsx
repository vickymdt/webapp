
import { useState, useEffect } from "react";

const recomendaciones = {
  "vinicius jr": { texto: "✅ Mantener: jugador top, diferencial en puntos Diario AS. [Delantero]", puntos: 210 },
  "kubo": { texto: "✅ Fichar si puedes: puntos regulares, gran forma. [Centrocampista]", puntos: 185 },
  "oyarzabal": { texto: "✅ Fichar: fiable, tira penaltis y buen rendimiento. [Delantero]", puntos: 190 },
  "koke": { texto: "⚠️ Fichaje útil si necesitas mediocentro estable. [Centrocampista]", puntos: 135 },
  "lewandowski": { texto: "✅ Solo fichar si puedes mantener plantilla equilibrada. [Delantero]", puntos: 200 },
  "iheanacho": { texto: "⚠️ Apuesta arriesgada: fichar solo si titular. [Delantero]", puntos: 85 },
  "losada": { texto: "❌ Vender: sin minutos ni valor. [Delantero]", puntos: 22 },
  "gumbau": { texto: "❌ Vender: no puntúa bien y sin impacto. [Centrocampista]", puntos: 44 },
  "espi": { texto: "❌ Vender: no juega. [Centrocampista]", puntos: 12 }
};

const sugerencias = Object.keys(recomendaciones).map((k) => k.replace(/\b\w/g, c => c.toUpperCase()));

const recomendacionesPorPosicion = {
  "portero": ["Sin datos disponibles"],
  "defensa": ["❗ Reforzar: Fichar centrales titulares con regularidad como Catena o Lejeune."],
  "centrocampista": ["✅ Kubo", "✅ Oyarzabal (también cuenta como mediapunta)", "⚠️ Koke si no hay opciones mejores"],
  "delantero": ["✅ Lewandowski si puedes equilibrar plantilla", "✅ Oyarzabal", "⚠️ Iheanacho si es titular"]
};

const capitalizar = (nombre) => nombre.replace(/\b\w/g, c => c.toUpperCase());

export default function BiwengerWebApp() {
  const [mediaRival, setMediaRival] = useState(150);
  const [jugador, setJugador] = useState("");
  const [recomendacion, setRecomendacion] = useState(null);
  const [necesidad, setNecesidad] = useState("");
  const [sugerenciasPorNecesidad, setSugerenciasPorNecesidad] = useState([]);
  const [historial, setHistorial] = useState(() => JSON.parse(localStorage.getItem("historial")) || []);

  const evaluarJugador = () => {
    const nombreNormalizado = jugador.trim().toLowerCase();
    const datos = recomendaciones[nombreNormalizado];
    if (datos) {
      setRecomendacion(datos);
      const nuevoHistorial = [...historial, { jugador: jugador.trim(), puntos: datos.puntos }];
      setHistorial(nuevoHistorial);
      localStorage.setItem("historial", JSON.stringify(nuevoHistorial));
    } else {
      setRecomendacion({ texto: "Jugador no encontrado en la base de datos.", puntos: null });
    }
  };

  const buscarPorNecesidad = () => {
    const clave = necesidad.trim().toLowerCase();
    const sugerencias = recomendacionesPorPosicion[clave] || ["No hay recomendaciones para esa posición."];
    setSugerenciasPorNecesidad(sugerencias);
  };

  return (
    <div style={{ padding: "2rem", maxWidth: "600px", margin: "0 auto" }}>
      <h1>Asistente Biwenger</h1>
      <input
        type="text"
        value={jugador}
        onChange={(e) => setJugador(e.target.value)}
        placeholder="Nombre del jugador"
      />
      <button onClick={evaluarJugador}>Evaluar Jugador</button>
      {recomendacion && <p>{recomendacion.texto}</p>}

      <hr />

      <input
        type="text"
        value={necesidad}
        onChange={(e) => setNecesidad(e.target.value)}
        placeholder="Posición (defensa, centrocampista...)"
      />
      <button onClick={buscarPorNecesidad}>Buscar por Posición</button>
      {sugerenciasPorNecesidad.map((s, idx) => (
        <p key={idx}>{s}</p>
      ))}
    </div>
  );
}
